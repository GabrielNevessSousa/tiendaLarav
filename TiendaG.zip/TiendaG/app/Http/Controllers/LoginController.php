<?php

namespace App\Http\Controllers;

use App\Models\LoginModel;
use Illuminate\Http\Request;
use App\Models\User;


use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index()
    {
        return view('login.login');
    }

    public function create()
    {
        // Puedes agregar lógica para mostrar el formulario de registro si es necesario
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');
    
        $user = User::where('email', $credentials['email'])->first();
    
        if ($user && $user->password === $credentials['password']) {
            Auth::login($user);
            return redirect()->intended('/dashboard');
        }
    
        return back()->withErrors(['email' => 'Invalid credentials']);
    }

    public function store(Request $request)
    {
        // Puedes agregar lógica para el registro de usuarios si es necesario
    }

    public function show($id)
    {
        // Puedes agregar lógica para mostrar detalles específicos si es necesario
    }

    public function dashboard()
    {

        
        $user = Auth::user();

        if ($user->role == 'administrador') {
            return view('admin.menuAdmin');
        } elseif ($user->role == 'usuario') {
            return view('menuUser.pagPrincipal');
        }
    }
}
