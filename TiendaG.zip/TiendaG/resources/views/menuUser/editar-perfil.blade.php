<!-- resources/views/menuUser/editar-perfil.blade.php -->

@extends('layouts.app')

@section('content')
    <h1>Editar Perfil</h1>

    <form method="POST" action="{{ route('perfil.update') }}">
        @csrf
        @method('PUT')

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="{{ old('nombre', $usuario->nombre) }}" required>
        <br>

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" value="{{ old('email', $usuario->email) }}" required>
        <br>

        <button type="submit">Guardar Cambios</button>
    </form>
@endsection
