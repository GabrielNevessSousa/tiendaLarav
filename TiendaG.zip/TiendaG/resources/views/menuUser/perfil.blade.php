<!-- resources/views/menuUser/perfil.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del Usuario</title>
</head>
<body>
    <h1>Perfil del Usuario</h1>

    @auth
        <p>Bienvenido, {{ auth()->user()->nombre }}</p>
        <p>Correo Electrónico: {{ auth()->user()->email }}</p>
        <p>Rol: {{ auth()->user()->role }}</p>

        <!-- Agregar enlace para editar el perfil -->
        <a href="{{ route('perfil.edit') }}">Editar Perfil</a>
    @else
        <p>No estás autenticado.</p>
    @endauth

    <!-- Agrega el botón de logout si estás utilizando un formulario -->
  
</body>
</html>
