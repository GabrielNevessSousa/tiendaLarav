<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Categorías</title>
</head>
<body>
    <h1>Bienvenido al Menú de Categorías</h1>

    <!-- Botones para acciones en categorías -->
    <a href="{{ route('admin.categorias.create') }}">
        <button>Añadir Categoría</button>
    </a>

    <a href="{{ route('admin.categorias.index') }}">
    <button>Mostrar Categorías</button>
</a>


    <a href="{{ route('admin.categorias.edit') }}">
        <button>Modificar Categoría</button>
    </a>

  

    <!-- Puedes seguir agregando más elementos HTML aquí -->

</body>
</html>
