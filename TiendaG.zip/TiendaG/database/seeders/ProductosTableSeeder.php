<?php

// database/seeders/ProductosTableSeeder.php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductosTableSeeder extends Seeder
{
    public function run()
    {
        // Puedes ajustar la cantidad de registros según tus necesidades
        $productos = [
            ['nombre' => 'Smartphone', 'descripcion' => 'Teléfono inteligente', 'unidades' => 50, 'precio_unitario' => 500, 'categoria' => 'Electrónicos'],
            ['nombre' => 'Camiseta', 'descripcion' => 'Camiseta de algodón', 'unidades' => 100, 'precio_unitario' => 20, 'categoria' => 'Ropa'],
            // Agrega más registros según sea necesario
        ];

        DB::table('productos')->insert($productos);
    }
}
