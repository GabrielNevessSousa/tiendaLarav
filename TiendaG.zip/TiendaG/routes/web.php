<?php
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\PerfilController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\HolaController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');

   

});
// Rutas para el controlador LoginController
// Rutas para el controlador LoginController
Route::get('/login', [LoginController::class, 'index'])->name('login.index');
Route::post('/login', [LoginController::class, 'authenticate']);


// Rutas para el controlador RegisterController
Route::get('/register', [RegisterController::class, 'index'])->name('register.index');

Route::post('/register', [RegisterController::class, 'store'])->name('register.store');

// En tu web.php
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [LoginController::class, 'dashboard'])->name('dashboard');

    Route::middleware(['role:usuario'])->group(function () {
        Route::get('/menuUser', [LoginController::class, 'index'])->name('menuUser.index');

    });
});

Route::get('/perfil', [PerfilController::class, 'index'])->name('perfil.index');
Route::get('/perfil/editar', [PerfilController::class, 'edit'])->name('perfil.edit');
Route::put('/perfil/editar', [PerfilController::class, 'update'])->name('perfil.update');


Route::get('/admin/productos', [ProductoController::class, 'index'])->name('admin.productos.index');



// Rutas para el menú de categorías
Route::get('/admin/categorias/menu', function () {
    return view('admin.categorias.menuCategoria');
})->name('admin.categorias.menu');


// Rutas para la sección de categorías
// Rutas para la sección de categorías
Route::get('/admin/categorias', [HolaController::class, 'index'])->name('admin.categorias.index');

Route::get('/admin/categorias/create', [HolaController::class, 'create'])->name('admin.categorias.create');
Route::get('/admin/categorias/show', [HolaController::class, 'show'])->name('admin.categorias.show');
Route::get('/admin/categorias/edit', [HolaController::class, 'edit'])->name('admin.categorias.edit');
Route::delete('/admin/categorias/{id}', [HolaController::class, 'destroy'])->name('admin.categorias.destroy');
