<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <h1>Registro</h1>
    <form method="POST" action="<?php echo e(route('register.store')); ?>">
        <?php echo csrf_field(); ?>
        
        <!-- Campos del formulario -->
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br>

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" required>
        <br>

        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>
        <br>

        <label for="role">Rol:</label>
        <select id="role" name="role" required>
            <option value="usuario">usuario</option>
            <option value="administrador">administrador</option>
        </select>
        <br>

        <!-- Botón de envío -->
        <button type="submit">Registrarse</button>
    </form>

    <!-- Enlace para cancelar y volver al login -->
    <a href="<?php echo e(route('login.index')); ?>">Cancelar</a>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\TiendaG\resources\views/login/register.blade.php ENDPATH**/ ?>