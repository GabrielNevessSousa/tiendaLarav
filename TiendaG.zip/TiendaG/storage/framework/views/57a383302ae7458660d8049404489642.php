<!-- resources/views/welcome.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido</title>
</head>
<body>
    <h1>Hola Usuario</h1>

    <a href="<?php echo e(route('perfil.index')); ?>"> <!-- Asegúrate de tener la ruta correcta para el perfil -->
        <button>Mi perfil</button>
    </a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TiendaG\resources\views/menuUser/pagPrincipal.blade.php ENDPATH**/ ?>