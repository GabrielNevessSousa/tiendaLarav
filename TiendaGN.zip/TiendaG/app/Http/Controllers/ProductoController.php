<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductoModel; // Asegúrate de importar el modelo User si no lo has hecho

class ProductoController extends Controller
{
    public function index()
    {
        // Obtener todos los productos desde la base de datos
        $productos = ProductoModel::all();

        // Retornar la vista con los productos
        return view('admin.productos.mostrar', ['productos' => $productos]);
    }

    public function create()
    {
        // Mostrar el formulario para crear una nueva categoría
       
    }

    public function store(Request $request)
    {
        // Validación de datos
 
    }

   public function edit($id)
    {
       
    }

    public function destroy($id)
    {
        // Buscar la categoría por ID
       
    }
    public function update(Request $request, $id)
    {
       
    }
    
    // Otros métodos del controlador...
}
