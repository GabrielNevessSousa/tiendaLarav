<?php

namespace App\Http\Controllers;

use App\Models\LoginModel;
use Illuminate\Http\Request;
use App\Models\CategoriaModel;


use Illuminate\Support\Facades\Auth;

class HolaController extends Controller
{

    
        // Obtener todas las categorías desde la base de datos
        public function index()
        {
            $categorias = CategoriaModel::all();
            return view('admin.categorias.mostrar', ['categorias' => $categorias]);
        }
        
    

    public function create()
    {
        // Mostrar el formulario para crear una nueva categoría
        return view('admin.categorias.crearCategoria');
    }

    public function store(Request $request)
    {
        // Validación de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
        ]);

        // Crear una nueva categoría en la base de datos
        CategoriaModel::create([
            'nombre' => $request->input('nombre'),
            'descripcion' => $request->input('descripcion'),
        ]);

        // Redirigir a la lista de categorías con un mensaje de éxito
        return redirect()->route('admin.categorias.index')->with('success', 'Categoría creada exitosamente.');
    }

   public function edit($id)
    {
        // Buscar la categoría por su ID
        $categoria = CategoriaModel::findOrFail($id);

        // Mostrar el formulario de edición con los datos de la categoría
        return view('admin.categorias.editarCategoria', ['categoria' => $categoria]);
    }

    public function destroy($id)
    {
        // Buscar la categoría por ID
        $categoria = CategoriaModel::find($id);

        // Verificar si la categoría existe


        // Eliminar la categoría
        $categoria->delete();

        // Redirigir a la lista de categorías con un mensaje de éxito
        return redirect()->route('admin.categorias.index')->with('success', 'Categoría eliminada exitosamente.');
    }
    public function update(Request $request, $id)
    {
        // Lógica para actualizar la categoría con el ID proporcionado
        $categoria = CategoriaModel::findOrFail($id);
        $categoria->nombre = $request->input('nombre');
        // Actualiza otros campos según sea necesario
        $categoria->save();
    
        return redirect()->route('admin.categorias.index')->with('success', 'Categoría actualizada correctamente');
    }
    



}