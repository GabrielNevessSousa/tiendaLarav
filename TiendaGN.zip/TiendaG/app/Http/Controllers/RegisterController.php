<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; // Asegúrate de importar el modelo User si no lo has hecho

class RegisterController extends Controller
{
    public function index()
    {
        return view('login.register');
    }

    public function store(Request $request)
    {
        // Validación de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required',
            'password' => 'required|min:6',
            'role' => 'required|in:usuario,administrador',
        ]);

        // Crear un nuevo usuario en la base de datos
        $user = new User([
            'nombre' => $request->input('nombre'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'role' => $request->input('role'),
        ]);

      

        $user->save();

        // Puedes redirigir a la página de inicio de sesión o a donde desees después de guardar el usuario
        return redirect()->route('login.index')->with('success', 'Registro exitoso. Por favor, inicia sesión.');
    }

    // Otros métodos del controlador...
}
