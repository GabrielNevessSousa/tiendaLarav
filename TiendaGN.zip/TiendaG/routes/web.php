<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\PerfilController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\HolaController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Rutas para el controlador LoginController
Route::get('/login', [LoginController::class, 'index'])->name('login.index');
Route::post('/login', [LoginController::class, 'authenticate']);

// Rutas para el controlador RegisterController
Route::get('/register', [RegisterController::class, 'index'])->name('register.index');
Route::post('/register', [RegisterController::class, 'store'])->name('register.store');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [LoginController::class, 'dashboard'])->name('dashboard');

    Route::middleware(['role:usuario'])->group(function () {
        Route::get('/menuUser', [LoginController::class, 'index'])->name('menuUser.index');
    });

    Route::middleware(['role:administrador'])->group(function () {
        Route::get('/admin/menuAdmin', function () {
            return view('admin.menuAdmin');
        })->name('admin.menuAdmin');

        // Rutas para productos en la carpeta admin/productos
     
        Route::get('/admin/productos/menu', function () {
            return view('admin.productos.menuProducto');
        })->name('admin.productos.menu');
    });
});




Route::prefix('/admin/categorias')->group(function () {
    Route::get('/menu', function () {
        return view('admin.categorias.menuCategoria');
    })->name('admin.categorias.menu');

    Route::get('/', [HolaController::class, 'index'])->name('admin.categorias.index');
    Route::get('/create', [HolaController::class, 'create'])->name('admin.categorias.create');
    Route::post('/store', [HolaController::class, 'store'])->name('admin.categorias.store');
    Route::get('/show/{id}', [HolaController::class, 'show'])->name('admin.categorias.show');
    Route::get('/edit/{id}', [HolaController::class, 'edit'])->name('admin.categorias.edit');
    Route::delete('/destroy/{id}', [HolaController::class, 'destroy'])->name('admin.categorias.destroy');
    Route::put('/update/{id}', [HolaController::class, 'update'])->name('admin.categorias.update');
});
