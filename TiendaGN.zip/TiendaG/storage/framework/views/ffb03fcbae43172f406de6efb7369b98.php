<!-- resources/views/categorias/editarCategoria.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Editar Categoría</h1>

    <form action="<?php echo e(route('admin.categorias.update', ['id' => $categoria->id_categoria])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo e($categoria->nombre); ?>" required>

        <!-- Otros campos del formulario según sea necesario -->

        <button type="submit">Guardar Cambios</button>
    </form>

    <a href="<?php echo e(route('admin.categorias.index')); ?>">
        <button>Volver al Listado</button>
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaG\resources\views/admin/categorias/editarCategoria.blade.php ENDPATH**/ ?>