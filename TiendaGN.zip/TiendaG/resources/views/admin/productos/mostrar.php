<!-- En tu vista para mostrar productos (admin.productos.show.blade.php) -->
@extends('layouts.app')

@section('content')
    <h1>Listado de Productos</h1>

    @if($productos->isEmpty())
        <p>No hay productos disponibles.</p>
    @else
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($productos as $producto)
                    <tr>
                        <td>{{ $producto->id_producto }}</td>
                        <td>{{ $producto->nombre }}</td>
                        <td>{{ $producto->descripcion }}</td>
                        <td>
                            <!-- Botón para editar -->
                            <a href="{{ route('admin.productos.edit', ['id' => $producto->id_producto]) }}">Editar</a>
                            
                            <!-- Formulario para eliminar -->
                            <form action="{{ route('admin.productos.destroy', ['id' => $producto->id_producto]) }}" method="post">
                                @csrf
                                @method('delete')
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Botón para volver al menú de administrador de productos -->
        <a href="{{ route('admin.productos.menu') }}">
            <button>Volver al Menú de Productos</button>
        </a>

        <!-- Botón para crear nuevo producto -->
        <a href="{{ route('admin.productos.create') }}">
            <button>Crear Nuevo Producto</button>
        </a>
    @endif
@endsection
