<!-- En tu vista para mostrar categorías (admin.categorias.show.blade.php) -->
@extends('layouts.app')

@section('content')
    <h1>Listado de Categorías</h1>

    @if($categorias->isEmpty())
        <p>No hay categorías disponibles.</p>
    @else
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($categorias as $categoria)
                    <tr>
                        <td>{{ $categoria->id_categoria }}</td>
                        <td>{{ $categoria->nombre }}</td>
                        <td>{{ $categoria->descripcion }}</td>
                        <td>
                            <form action="{{ route('admin.categorias.destroy', ['id' => $categoria->id_categoria]) }}" method="post">
                                @csrf
                                @method('delete')
                                <button type="submit">Eliminar</button>
                            </form>
                            <!-- Botón para editar -->
                            <a href="{{ route('admin.categorias.edit', ['id' => $categoria->id_categoria]) }}">Editar</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Botón para volver al menú de categorías -->
        <a href="{{ route('admin.categorias.menu') }}">
            <button>Volver</button>
        </a>

        <!-- Botón para crear nueva categoría -->
        <a href="{{ route('admin.categorias.create') }}">
            <button>Crear</button>
        </a>
    @endif
@endsection
