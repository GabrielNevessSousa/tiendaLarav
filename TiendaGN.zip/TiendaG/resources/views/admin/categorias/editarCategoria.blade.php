<!-- resources/views/categorias/editarCategoria.blade.php -->
@extends('layouts.app')

@section('content')
    <h1>Editar Categoría</h1>

    <form action="{{ route('admin.categorias.update', ['id' => $categoria->id_categoria]) }}" method="post">
        @csrf
        @method('put')

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="{{ $categoria->nombre }}" required>

        <!-- Otros campos del formulario según sea necesario -->

        <button type="submit">Guardar Cambios</button>
    </form>

    <a href="{{ route('admin.categorias.index') }}">
        <button>Volver al Listado</button>
    </a>
@endsection
